## Links
- [Monitoria ED Whatsapp](https://chat.whatsapp.com/7jENvA7CcMjE27zedcAJcK)
- [Repositório Git Exemplo](https://github.com/senapk/exemplo_repositorio_disciplina)

## s01e01 - Apresentação
- presença
- valores
    - honestidade
    - justiça
- notas
    - somatório ponderado dos trabalhos
- moodle.quixada.ufc.br
    - "ed is fun"
- C++
    - construir as nossas estruturas
        - c - faca
    - resolver problemas com ED
        - c++ - muito complexa - sabre de luz
        - https://www.learncpp.com

## s01e02
- criar uma conta no moodle
- começar a estudar c++
- criar uma conta no github.

## s02e01
- Estudar o decaptar
- Fazer o decaptar 2

## s02e02
- Estudar a queimada
- Fazer o labirinto
