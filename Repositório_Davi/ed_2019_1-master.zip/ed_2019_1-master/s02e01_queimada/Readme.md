## [rec, pilha] Queimada
## @qxcode

Dado uma matriz que representa espaços vazios e árvores e um ponto inicial onde começa o fogo, retorne a matriz com as árvores queimadas.

A matriz está codificada assim.
1a linha: nl, nc, l, c sendo: número de linhas e colunas da matriz, linha e coluna onde começa o fogo.
linhas subsequentes
- '\#' representa uma árvore
- '.' representa um espaço vazio
- 'o' representa uma árvore queimada

Saída esperada:
- Imprima a matriz após a queimada acontecer.


```
>>>>>>>> 01
2 3 1 1
#.#
.##
========
#.o
.oo
<<<<<<<<

>>>>>>>> 02
5 5 0 0
#..#.
#...#
###..
..#.#
..###
========
o..#.
o...#
ooo..
..o.o
..ooo
<<<<<<<<

>>>>>>>> 03
5 7 2 3
#..#.#.
#..####
####..#
..#.#.#
#.###..
========
o..o.o.
o..oooo
oooo..o
..o.o.o
#.ooo..
<<<<<<<<

>>>>>>>> 04
5 5 0 0
...#.
#...#
###..
..#.#
..###
========
...#.
#...#
###..
..#.#
..###
<<<<<<<<
```

<!---
>>>>>>>> 05
50 100 0 4
.#..#.#.#.....#.#..##.#.####..##...###..#.#.###.###..###.###..#.##.##..###..#.##.###.##.##..###.###.
.#.##.##.#.##..#..#...#.#.##.#####.#.#...#.....######..###.##..###.#.########..##..###..#.###....###
##.##.####.########.####.##########..##.###.#.#...##...###..##..#####.###..###.####..###.#..#...#..#
..##.#########..#.###.#...#..###.#######..##..#.#.###..#.#####.#.##....#..####.#..#..#.###..#.#.####
.###.#######.###.#######.#######.#.#..##.####...##.#...###...###..########.########...##.#.##...##.#
.###########.##..###.########.#..##..###.#...###..#.#....######.##..#.#.#.....##.##.##..######..#..#
####....#.######.#.....#...###.##....##.#.....##..#.####.#.##.###.#.##.#.#.##..##..#.#...####.##..##
..####.##.#...#####..#.##..#.####.######.#.#####...####..####.######.#.###.#####.##...###.####.#####
##..##.#.##.######..#.#####.#####.##.######..###.##.###.#####.#..#.#####..#......###..####..####.###
..#.#....#.#..###..##.#.#.#####.##..####...#.#.##.##.###.###.###.##..##..#...##.##.##.###..#..##....
#####.#.#..#.#.#.#######..#.#..####..#.##.#.#.#####.#.###..###.#####.#.###.#....##.#..####.##.#.####
#.###.#..##.#.##.#.##....#..###.########.##..###..#.#.##..##.....#######..#.###....#..#.#.#.#.####..
#..#.#.#########....#########.#.......###.###.#...###..###.####.##########.##..#.###..##..#####.###.
#.#.#.#...#...#####.#.#...#.##.###.##.###...#.####.#..#########.#.###.######.#.#.####.#.##.##.#..###
.....####.#.####..#..#.##..##.##...#..#...####.#...#####.#..###.######.###.#####..#..#######.#.###.#
#...###....#######.####..#.###.##.###...##...###.###.##.#..###..##.##.##.#.#.###..#.#.##.#.#######.#
..#...#.#.###.#####.#.#.##.###..########.#.##.####..###...####..#.####.##.#.#..###.####..##..######.
##...####.#.#####.#..#.##.#..##...########..#######.#####.#.#.#.#.##.##.#.#.##..#.#.#.#.#...###.##..
#..####..####.###..#.##..##.##.#.#.#..#..###.#.###..######.###.#.##..####...##..##.#.#..#.##.#######
#.....###.##..##.####.#####.#.#.##.#########.##..##.#.....####.##.##.####.##########.....#..#...####
##.....#####...#..#.##.######...##..###.##..####.####...####..#######.#.#.#.#####.###...#####...####
######.#.#.#..#######......####.#....##..##..##.....##########.#..##.##.#.#######...###.....#####.##
###.##..#..#...##....#####.####.##########.#..########.##.###.##.##..#.##..########..#.#.#.#..#..###
##.######.#####..#.#...##...######.####.#.##.#.##.#..##########.#.######..####.####.####.###..##.#.#
.#.##.##.#.#########.#..##..##.###.#.#.#.######..###..##.##.#.#....#.#.#.###.##.#.#...########.##..#
.####.##..##.#####.###.##...######..##.####.###...##.###.#.#...#####.#...#.###.##########.########..
#######.#.#.....#####..#..##..#.#.#########..##.#.#....#.#.###.#.####....#########.#######.#######.#
###.####..##.#.#....##########.##.#.#...######....###..##.####...####.#########.#..#.#.#..##.#.#.###
..##.##.#.#.#...##.#..###.####....#..###.....###.###.#.#.#.##.#.#....#.####.####.##.######.##....###
#####.#########...####.##..##..##.##.#...#....#######...##.###.#######.####.##..#.####..#####...####
##..#.#.#......#.#.#.##.#.#..#.##...##.#####..##.###.##.##..##.#..###..###.####..#.####.#..#.#.####.
..##..####.#.##.##.######.#..##.######.##.######.#...#.####.######...##..#.#.#..######.#..#..##...#.
#.###.######.####..####.#############.###..####..#######..###.##.####.#.#...####.###.####.###..##..#
#.###...#......#####.#.#..#..#.#......########.#####..###.#.######.##.###.#####....######.##.###.###
####...######.....####...#.################.#####...##.##.##...####..##.#.##..#####..##...##.####.##
#.#.#.###.#...#...##..#.##.#####.##.###.#.#.#.####.##.#..###....#.###....#.####..#.#####.#.###.####.
.##.#######....#..##..#..#.##.##.#.####..####..#..#..#.######..###..#####.####.#.#.#.####.#####...##
#.#.##..#.#.#.###.#...#..#.##.#####..#########.....#.##.#..#.###.##...###.#....########.####....###.
#####.##.####.##.#.##.####.#####.####.#####.#...#.###...####.#..#.###.####.#.#..##.###.#.#..###.##..
#####.#########.#.###.......#############.#.#.#.##.##.#.##.##.#######....##.##..#.######.##########.
#.#.##..#..#..####..##########...#.###.####..###.###.##.#####.#############.#.###.#########..#######
.###..#.#####...##..##.##.##.#.##..##.##....########.###...##..#..####.###.####.#.#..#..##.#.##.#.##
#.#.####.##..#.##.#########.####..#.#.##.##..########.#.#.#..##.#.#.##.######...##.##..#.#.##..####.
#.#.###..#.##..######.#..##.#..#.########.#.##..###.##.##.##.#.#....##.##.######.###.##.#.###.##...#
#.###.#...###..#.##########...##.###.#.########.####.##.###.###.###.#..#.#...##..####..####..##..#.#
###.#....###.#.#....####.####.#..####..#####..#....##..###...###.#..#.#.#.###..###.##.#.#.#...###.##
.#.###.###..##.#########.######...###..##..##...##.##.##.#.###.########..#..#.#.####..#...###.###.#.
#####.##.#...#..#.#.######.######.#.###.##.#....#######..#..##..##.##.########....##.##.##..######..
.##.###...######.#...#.###...##.#....#.#.##.#..##.#######.#.##.#.####..##..#....#..#..##..###.##.##.
#..#######.#####.##.####.##.##.##...##..##.##..############.#.####...##.####.##.##..#....##.###.##..
========
.#..o.o.#.....#.#..##.o.oooo..oo...ooo..#.#.###.###..ooo.ooo..#.oo.oo..ooo..o.oo.ooo.oo.##..ooo.ooo.
.#.oo.oo.o.oo..o..o...o.o.oo.ooooo.o.o...#.....######..ooo.oo..ooo.o.oooooooo..oo..ooo..#.ooo....ooo
##.oo.oooo.oooooooo.oooo.oooooooooo..oo.###.#.#...##...ooo..oo..ooooo.ooo..ooo.oooo..ooo.o..o...o..o
..oo.ooooooooo..o.ooo.o...o..ooo.ooooooo..##..#.#.###..o.ooooo.o.oo....o..oooo.o..o..o.ooo..o.#.oooo
.ooo.ooooooo.ooo.ooooooo.ooooooo.o.o..oo.####...##.#...ooo...ooo..oooooooo.oooooooo...oo.o.oo...oo.o
.ooooooooooo.oo..ooo.oooooooo.o..oo..ooo.#...ooo..#.o....oooooo.oo..o.o.o.....oo.oo.##..oooooo..o..o
oooo....o.oooooo.o.....o...ooo.oo....oo.#.....oo..#.oooo.o.oo.ooo.o.oo.o.o.oo..oo..#.#...oooo.oo..oo
..oooo.oo.o...ooooo..#.oo..o.oooo.oooooo.o.ooooo...oooo..oooo.oooooo.o.ooo.ooooo.##...ooo.oooo.ooooo
##..oo.o.oo.oooooo..o.ooooo.ooooo.oo.oooooo..ooo.oo.ooo.ooooo.o..o.ooooo..#......###..oooo..oooo.ooo
..o.o....o.#..ooo..oo.o.o.ooooo.oo..oooo...#.o.oo.oo.ooo.ooo.ooo.oo..oo..o...##.##.##.ooo..o..oo....
ooooo.#.#..#.#.o.ooooooo..o.o..oooo..o.oo.o.#.ooooo.o.ooo..ooo.ooooo.o.ooo.#....##.#..oooo.oo.o.oooo
o.ooo.#..oo.o.oo.o.oo....o..ooo.oooooooo.oo..ooo..o.o.oo..oo.....ooooooo..#.ooo....#..o.o.o.o.oooo..
o..o.#.ooooooooo....ooooooooo.o.......ooo.ooo.o...ooo..ooo.oooo.oooooooooo.oo..o.###..oo..ooooo.ooo.
o.#.#.o...o...ooooo.o.o...o.oo.ooo.oo.ooo...o.oooo.o..ooooooooo.o.ooo.oooooo.o.o.####.o.oo.oo.o..ooo
.....oooo.o.oooo..o..#.##..oo.oo...o..o...oooo.o...ooooo.o..ooo.oooooo.ooo.ooooo..#..ooooooo.o.ooo.o
#...ooo....ooooooo.####..#.ooo.oo.ooo...oo...ooo.ooo.oo.#..ooo..oo.oo.oo.o.o.ooo..#.o.oo.o.ooooooo.o
..#...o.o.ooo.ooooo.#.#.##.ooo..oooooooo.o.oo.oooo..ooo...oooo..o.oooo.oo.#.o..ooo.oooo..oo..oooooo.
oo...oooo.o.ooooo.o..o.##.o..oo...oooooooo..ooooooo.ooooo.o.o.#.o.oo.oo.o.#.oo..o.#.o.o.#...ooo.oo..
o..oooo..oooo.ooo..o.oo..oo.oo.#.o.o..o..ooo.o.ooo..oooooo.ooo.o.oo..oooo...oo..oo.o.#..#.##.ooooooo
o.....ooo.oo..oo.oooo.ooooo.o.#.oo.ooooooooo.oo..oo.o.....oooo.oo.oo.oooo.oooooooooo.....o..o...oooo
oo.....ooooo...o..o.oo.oooooo...oo..ooo.oo..oooo.oooo...oooo..ooooooo.o.o.o.ooooo.ooo...ooooo...oooo
oooooo.o.o.o..ooooooo......oooo.o....oo..oo..oo.....oooooooooo.o..oo.oo.o.ooooooo...ooo.....ooooo.oo
ooo.oo..o..o...oo....ooooo.oooo.oooooooooo.o..oooooooo.oo.ooo.oo.oo..o.oo..oooooooo..o.o.o.o..o..ooo
oo.oooooo.ooooo..o.o...oo...oooooo.oooo.o.oo.o.oo.o..oooooooooo.#.oooooo..oooo.oooo.oooo.ooo..oo.o.o
.o.oo.oo.#.ooooooooo.o..oo..oo.ooo.o.o.o.oooooo..ooo..oo.oo.o.o....o.o.o.ooo.oo.o.o...oooooooo.oo..o
.oooo.oo..oo.ooooo.ooo.oo...oooooo..oo.oooo.ooo...oo.ooo.o.o...ooooo.o...o.ooo.oooooooooo.oooooooo..
ooooooo.#.o.....ooooo..o..oo..o.o.ooooooooo..oo.#.o....o.o.ooo.o.oooo....ooooooooo.ooooooo.ooooooo.o
ooo.oooo..oo.#.#....oooooooooo.oo.o.o...oooooo....ooo..oo.oooo...oooo.ooooooooo.o..o.o.o..oo.o.o.ooo
..oo.oo.o.o.o...##.o..ooo.oooo....o..ooo.....ooo.ooo.#.o.o.oo.#.o....o.oooo.oooo.oo.oooooo.oo....ooo
ooooo.ooooooooo...oooo.oo..oo..oo.oo.o...o....ooooooo...oo.ooo.ooooooo.oooo.oo..#.oooo..ooooo...oooo
oo..o.o.o......#.o.o.oo.o.o..o.oo...oo.ooooo..oo.ooo.oo.oo..oo.o..ooo..ooo.oooo..o.oooo.o..o.#.oooo.
..oo..oooo.o.oo.oo.oooooo.o..oo.oooooo.oo.oooooo.o...o.oooo.oooooo...##..o.o.o..oooooo.o..o..##...o.
o.ooo.oooooo.oooo..oooo.ooooooooooooo.ooo..oooo..ooooooo..ooo.oo.oooo.#.#...oooo.ooo.oooo.ooo..oo..o
o.ooo...o......ooooo.o.#..o..o.o......oooooooo.ooooo..ooo.o.oooooo.oo.###.ooooo....oooooo.oo.ooo.ooo
oooo...oooooo.....oooo...#.oooooooooooooooo.ooooo...##.oo.oo...oooo..##.#.oo..ooooo..oo...oo.oooo.oo
o.o.o.ooo.o...#...oo..#.##.ooooo.oo.ooo.o.o.o.oooo.##.#..ooo....o.ooo....#.oooo..o.ooooo.#.ooo.oooo.
.oo.ooooooo....o..oo..#..#.oo.oo.o.oooo..oooo..o..#..#.oooooo..ooo..ooooo.oooo.o.o.o.oooo.ooooo...oo
o.o.oo..o.o.o.ooo.o...#..#.oo.ooooo..ooooooooo.....o.##.o..o.ooo.oo...ooo.o....oooooooo.oooo....ooo.
ooooo.oo.oooo.oo.#.oo.####.ooooo.oooo.ooooo.o...o.ooo...oooo.o..o.ooo.oooo.#.o..oo.ooo.o.o..ooo.oo..
ooooo.ooooooooo.o.ooo.......ooooooooooooo.o.o.o.oo.oo.#.oo.oo.ooooooo....oo.oo..o.oooooo.oooooooooo.
o.o.oo..o..o..oooo..oooooooooo...o.ooo.oooo..ooo.ooo.##.ooooo.ooooooooooooo.o.ooo.ooooooooo..ooooooo
.ooo..o.ooooo...oo..oo.oo.oo.o.oo..oo.oo....oooooooo.###...oo..o..oooo.ooo.oooo.o.o..o..oo.o.oo.o.oo
o.o.oooo.oo..#.oo.ooooooooo.oooo..o.o.oo.oo..oooooooo.#.o.o..oo.#.o.oo.oooooo...oo.oo..#.o.oo..oooo.
o.o.ooo..o.oo..oooooo.o..oo.o..o.oooooooo.o.oo..ooo.oo.oo.oo.o.#....oo.oo.oooooo.ooo.##.o.ooo.oo...#
o.ooo.o...ooo..o.oooooooooo...oo.ooo.o.oooooooo.oooo.oo.ooo.ooo.ooo.o..o.#...oo..oooo..oooo..oo..#.#
ooo.o....ooo.#.o....oooo.oooo.o..oooo..ooooo..o....oo..ooo...ooo.o..o.o.#.ooo..ooo.oo.#.o.o...ooo.##
.o.ooo.ooo..##.ooooooooo.oooooo...ooo..oo..oo...oo.oo.oo.o.ooo.oooooooo..o..o.#.oooo..#...ooo.ooo.#.
ooooo.oo.o...#..o.o.oooooo.oooooo.o.ooo.oo.o....ooooooo..o..oo..oo.oo.oooooooo....oo.##.##..oooooo..
.oo.ooo...######.#...o.ooo...oo.o....o.#.oo.#..oo.ooooooo.o.oo.o.oooo..oo..o....#..o..##..ooo.oo.oo.
#..ooooooo.#####.##.oooo.oo.oo.oo...oo..oo.##..oooooooooooo.o.oooo...##.oooo.##.##..#....oo.ooo.oo..
<<<<<<<<



--->
